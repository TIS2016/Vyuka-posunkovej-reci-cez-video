1. run install.cmd
2. choose for "Customize installation"
3. in Optional Features, mark all 
4. set Customise install location for: "C:\Python35"
5. finish instalation